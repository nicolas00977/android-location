package com.nico.unilocal

data class DataPlace(val title: String, val desc: String)
